package com.example.saveme

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.saveme.R

abstract class MainActivity : AppCompatActivity() {

    internal abstract var btnsubmit: Button
    internal abstract var et_notelp: EditText
    internal abstract var tverrormessage: TextView
    // alt + insert

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnsubmit = findViewById(R.id.btn_submit)
        et_notelp = findViewById(R.id.et_notelp)
        tverrormessage = findViewById(R.id.tv_errormessage)

        btnsubmit.setOnClickListener {
            //                Toast.makeText(MainActivity.this, "Button Clicked", Toast.LENGTH_SHORT).show();
            val name = et_notelp.text.toString().trim { it <= ' ' }
            if (name.isEmpty()) {
                Toast.makeText(this@MainActivity, "Please input your phone number", Toast.LENGTH_SHORT)
                    .show()
            } else {
                // Pindah Page
                //                    Toast.makeText(MainActivity.this, name, Toast.LENGTH_SHORT).show();
                val intent = Intent(
                    this@MainActivity,
                    menu::class.java
                )
                intent.putExtra("name", name)
                startActivityForResult(intent, 100)
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100) {
            if (resultCode == 99) {
                val feedback = data!!.getStringExtra("feedback")
                tverrormessage.text = feedback
            }
        }
    }
}
